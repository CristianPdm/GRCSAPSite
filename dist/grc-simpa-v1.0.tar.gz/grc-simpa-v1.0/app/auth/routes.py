from datetime import datetime

from flask import flash, redirect, render_template, request, url_for
from flask_login import current_user, login_required, login_user, logout_user
from sqlalchemy import func

from app.auth import bp
from app.extensions import db
from app.models import AuditLog, User


@bp.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("main.dashboard"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")

        # Login insensible a mayusculas/minusculas: "Cris", "cris" y "CRIS"
        # deben loguear al mismo usuario.
        user = User.query.filter(func.lower(User.username) == username.lower()).first()

        if user is None or not user.check_password(password):
            AuditLog.log("login_fallido", username=username, ip_address=request.remote_addr)
            flash("Usuario o contraseña incorrectos.", "error")
            return render_template("auth/login.html")

        if not user.is_active_user:
            AuditLog.log("login_bloqueado", username=user.username, ip_address=request.remote_addr,
                         details="Usuario deshabilitado")
            flash("Tu cuenta está deshabilitada. Contacta al administrador.", "error")
            return render_template("auth/login.html")

        login_user(user)
        user.last_login_at = datetime.utcnow()
        db.session.commit()
        AuditLog.log("login_exitoso", username=user.username, ip_address=request.remote_addr)

        next_page = request.args.get("next")
        return redirect(next_page or url_for("main.dashboard"))

    return render_template("auth/login.html")


@bp.route("/logout")
@login_required
def logout():
    AuditLog.log("logout", username=current_user.username, ip_address=request.remote_addr)
    logout_user()
    flash("Sesión cerrada correctamente.", "info")
    return redirect(url_for("auth.login"