"""Importacion en lote de archivos SAP desde una carpeta configurable.

En lugar de subir cada tabla de a una (AGR_USERS.xlsx, AGR_1251.xlsx, etc.),
un administrador puede dejar todos los Excel exportados de SAP en una misma
carpeta del servidor y disparar un escaneo: este modulo busca, para cada
nombre de archivo esperado, un .xlsx con ese nombre (sin distinguir
mayusculas/minusculas) y ejecuta el importer correspondiente.

La carpeta en si se guarda con app.models.AppSetting (clave
SAP_IMPORT_FOLDER_SETTING), editable desde la pantalla de importacion de
SOD o de Licencias (es una sola carpeta compartida por ambos modulos).
"""
import os

SAP_IMPORT_FOLDER_SETTING = "sap_import_folder"


def scan_import_folder(folder, importers):
    """Escanea `folder` buscando un .xlsx por cada clave de `importers` y
    ejecuta el importer correspondiente sobre el primero que encuentre.

    `importers` es un dict {tipo: (label, importer_func)}, igual al que ya
    usan las rutas de importacion manual. `importer_func` recibe un stream
    de archivo abierto en modo binario.

    Devuelve una lista de resultados (uno por cada tipo esperado, en el
    mismo orden que `importers`), o None si la carpeta no existe o no se
    puede leer. Cada resultado es un dict con:
      - tipo, label: igual que la entrada de `importers`
      - found: True/False, si se encontro un archivo con ese nombre
      - ok: True si se encontro y se importo sin errores
      - count: filas importadas (solo si ok)
      - filename: nombre real del archivo encontrado (si found)
      - error: mensaje de error (si found y no ok)
    """
    if not folder or not os.path.isdir(folder):
        return None

    try:
        entries = os.listdir(folder)
    except OSError:
        return None

    # Mapea NOMBRE_SIN_EXTENSION (mayusculas) -> ruta completa del primer
    # .xlsx encontrado con ese nombre.
    found_by_stem = {}
    for entry in entries:
        full_path = os.path.join(folder, entry)
        if not os.path.isfile(full_path):
            continue
        stem, ext = os.path.splitext(entry)
        if ext.lower() != ".xlsx":
            continue
        stem_key = stem.strip().upper()
        if stem_key not in found_by_stem:
            found_by_stem[stem_key] = full_path

    results = []
    for tipo, (label, importer_func) in importers.items():
        path = found_by_stem.get(tipo.upper())

        if not path:
            results.append({
                "tipo": tipo, "label": label, "found": False, "ok": False,
            })
            continue

        filename = os.path.basename(path)
        try:
            with open(path, "rb") as stream:
                count = importer_func(stream)
            results.append({
                "tipo": tipo, "label": label, "found": True, "ok": True,
                "count": count, "filename": filename,
            })
        except Exception as exc:
            results.append({
                "tipo": tipo, "label": label, "found": True, "ok": False,
                "error": str(exc), "filename": filename,
            })

    return results
