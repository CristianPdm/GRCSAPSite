"""Importadores de archivos Excel SAP (AGR_*) hacia las tablas tipadas del
modulo SOD. Reemplazan el parseo en navegador (SheetJS) de
SAP_SOD_Importer_v2.html.

Cada importer borra los datos previos de su propia tabla y vuelve a
cargarlos completos (import "full refresh"), igual que el original.
"""
from app.extensions import db
from app.utils.excel import column_index, column_indices, parse_excel_date, read_excel_matrix

from app.sod.models import (
    SapRoleAssignment,
    SapRoleDescription,
    SapRoleTableAuth,
    SapRoleTcode,
    SapTcodeDescription,
)


def import_agr_users(file_stream):
    """AGR_USERS.xlsx: asignacion Rol -> Usuario, con vigencia y exclusion.
    Columnas reales: Rol(0), Usuarios(1), Fecha de inicio(2), Fecha fin(3),
    Excluido(4)."""
    headers, rows = read_excel_matrix(file_stream)

    role_idx = column_index(headers, ["ROL"])
    user_idx = column_index(headers, ["USUARIO"])
    fecha_fin_idx = column_index(headers, ["FECHA FIN"])
    excluido_idx = column_index(headers, ["EXCLUIDO"])

    if role_idx is None or user_idx is None:
        raise ValueError("AGR_USERS.xlsx: no se encontraron las columnas Rol/Usuario.")

    SapRoleAssignment.query.delete()

    count = 0
    for row in rows:
        if role_idx >= len(row) or user_idx >= len(row):
            continue
        role_name = row[role_idx]
        username = row[user_idx]
        if not role_name or not username:
            continue

        if excluido_idx is not None and excluido_idx < len(row):
            excluido_val = row[excluido_idx]
            if excluido_val and str(excluido_val).strip().upper() in ("X", "SI", "TRUE", "1"):
                continue

        valid_to = None
        if fecha_fin_idx is not None and fecha_fin_idx < len(row):
            valid_to = parse_excel_date(row[fecha_fin_idx])

        db.session.add(SapRoleAssignment(
            role_name=str(role_name).strip(),
            username=str(username).strip(),
            valid_to=valid_to,
        ))
        count += 1

    db.session.commit()
    return count


def import_agr_1251(file_stream):
    """AGR_1251.xlsx: transacciones (S_TCODE/TCD) habilitadas por cada rol,
    y de paso los roles con autorizacion irrestricta a tablas (objeto
    S_TABU_DIS, valor '*' -> bandera de riesgo en Roles criticos).
    Columnas reales: Rol(0), ID(1), Obj.autorizacion(2),
    Actual.maestro usuario...(3), Variante(4), Nombre campo(5),
    Valor de la autorizacion BAJO(6), Valor de la autorizacion ALTO(7,
    encabezado duplicado), Status del objeto(8)."""
    headers, rows = read_excel_matrix(file_stream)

    role_idx = column_index(headers, ["ROL"])
    obj_auth_idx = column_index(headers, ["OBJ.AUTORIZACION", "OBJ AUTORIZACION", "OBJETO DE AUTORIZACION"])
    field_name_idx = column_index(headers, ["NOMBRE CAMPO", "NOMBRE DE CAMPO"])
    valor_indices = column_indices(headers, ["VALOR DE LA AUTORIZACION", "VALOR AUTORIZACION"])

    if role_idx is None or obj_auth_idx is None or field_name_idx is None or not valor_indices:
        raise ValueError("AGR_1251.xlsx: estructura de columnas inesperada (Rol/Obj.autorizacion/Nombre campo/Valor).")

    SapRoleTcode.query.filter_by(source="AGR_1251").delete()
    SapRoleTableAuth.query.delete()

    count = 0
    seen = set()
    tabu_dis_roles = set()
    for row in rows:
        if role_idx >= len(row) or obj_auth_idx >= len(row) or field_name_idx >= len(row):
            continue
        obj_auth = str(row[obj_auth_idx] or "").strip().upper()
        field_name = str(row[field_name_idx] or "").strip().upper()

        role_name = row[role_idx]
        if not role_name:
            continue
        role_name = str(role_name).strip()

        if obj_auth == "S_TABU_DIS":
            for vidx in valor_indices:
                if vidx >= len(row):
                    continue
                if str(row[vidx] or "").strip() == "*":
                    tabu_dis_roles.add(role_name)
                    break
            continue

        if obj_auth != "S_TCODE" or field_name != "TCD":
            continue

        for vidx in valor_indices:
            if vidx >= len(row):
                continue
            raw_value = row[vidx]
            if not raw_value:
                continue
            # un mismo campo puede traer varios tcodes separados por coma/espacio
            for tcode in str(raw_value).replace(",", " ").split():
                tcode = tcode.strip().upper()
                if not tcode:
                    continue
                key = (role_name, tcode)
                if key in seen:
                    continue
                seen.add(key)
                db.session.add(SapRoleTcode(role_name=role_name, tcode=tcode, source="AGR_1251"))
                count += 1

    for role_name in tabu_dis_roles:
        db.session.add(SapRoleTableAuth(role_name=role_name))

    db.session.commit()
    return count


def import_agr_tcodes(file_stream):
    """AGR_TCODES.xlsx: alternativa/respaldo a AGR_1251 para tcode por rol.
    Columnas reales: Rol(0), Tp.report(1), Nombre ampliado(2), Excluido(3),
    Transaccion introducida directamente(4), Transaccion heredada de rol
    predecesor(5), ID(6). Solo las filas con Tp.report == 'TR' traen un
    tcode real en 'Nombre ampliado' (las 'OT' son apps Fiori/WebDynpro)."""
    headers, rows = read_excel_matrix(file_stream)

    role_idx = column_index(headers, ["ROL"])
    tp_report_idx = column_index(headers, ["TP.REPORT", "TP REPORT"])
    tcode_idx = column_index(headers, ["NOMBRE AMPLIADO"])
    excluido_idx = column_index(headers, ["EXCLUIDO"])

    if role_idx is None or tp_report_idx is None or tcode_idx is None:
        raise ValueError("AGR_TCODES.xlsx: estructura de columnas inesperada (Rol/Tp.report/Nombre ampliado).")

    SapRoleTcode.query.filter_by(source="AGR_TCODES").delete()

    count = 0
    seen = set()
    for row in rows:
        if role_idx >= len(row) or tp_report_idx >= len(row) or tcode_idx >= len(row):
            continue
        tp_report = str(row[tp_report_idx] or "").strip().upper()
        if tp_report != "TR":
            continue

        if excluido_idx is not None and excluido_idx < len(row):
            excluido_val = row[excluido_idx]
            if excluido_val and str(excluido_val).strip().upper() in ("X", "SI", "TRUE", "1"):
                continue

        role_name = row[role_idx]
        tcode = row[tcode_idx]
        if not role_name or not tcode:
            continue

        role_name = str(role_name).strip()
        tcode = str(tcode).strip().upper()
        key = (role_name, tcode)
        if key in seen:
            continue
        seen.add(key)
        db.session.add(SapRoleTcode(role_name=role_name, tcode=tcode, source="AGR_TCODES"))
        count += 1

    db.session.commit()
    return count


def import_agr_define(file_stream):
    """AGR_DEFINE.xlsx: descripcion de cada rol (solo informativo).
    Columnas reales: Rol(0, con datos), Rol(1, duplicado, vacio),
    Usuario(2)...Descripcion breve del rol(ultima columna)."""
    headers, rows = read_excel_matrix(file_stream)

    role_idx = column_index(headers, ["ROL"])
    desc_idx = column_index(headers, ["DESCRIPCION BREVE", "DESCRIPCION DEL ROL", "DESCRIPCION"])

    if role_idx is None or desc_idx is None:
        raise ValueError("AGR_DEFINE.xlsx: no se encontraron 