"""Modelos de datos del modulo SOD/GRC.

Reemplazan, con columnas tipadas, al esquema original de
SAP_SOD_Importer_v2.html / SAP_SOD_Analyzer_v640.html, que guardaba cada
fila importada como un blob JSON generico (tabla `(id, data TEXT)`).
"""
import json
from datetime import datetime

from app.extensions import db


class SapRoleAssignment(db.Model):
    """Asignacion rol -> usuario, importada de AGR_USERS.xlsx."""

    __tablename__ = "sap_role_assignments"

    id = db.Column(db.Integer, primary_key=True)
    role_name = db.Column(db.String(80), nullable=False, index=True)
    username = db.Column(db.String(40), nullable=False, index=True)
    valid_to = db.Column(db.Date, nullable=True)  # "Fecha fin"; None/9999 = vigente
    imported_at = db.Column(db.DateTime, default=datetime.utcnow)


class SapRoleTcode(db.Model):
    """Transaccion habilitada por un rol, importada de AGR_1251.xlsx
    (objeto S_TCODE, preferido) o AGR_TCODES.xlsx (alternativa/respaldo)."""

    __tablename__ = "sap_role_tcodes"

    id = db.Column(db.Integer, primary_key=True)
    role_name = db.Column(db.String(80), nullable=False, index=True)
    tcode = db.Column(db.String(40), nullable=False, index=True)
    source = db.Column(db.String(20), default="AGR_1251")  # AGR_1251 | AGR_TCODES
    imported_at = db.Column(db.DateTime, default=datetime.utcnow)


class SapRoleDescription(db.Model):
    """Descripcion de rol, importada de AGR_DEFINE.xlsx (solo informativo)."""

    __tablename__ = "sap_role_descriptions"

    id = db.Column(db.Integer, primary_key=True)
    role_name = db.Column(db.String(80), unique=True, nullable=False)
    description = db.Column(db.String(255), default="")
    imported_at = db.Column(db.DateTime, default=datetime.utcnow)


class SapRoleTableAuth(db.Model):
    """Roles con autorizacion irrestricta a tablas (objeto S_TABU_DIS con
    valor '*'), detectados al importar AGR_1251.xlsx. Se usa como bandera
    sintetica de riesgo ALTO en la vista de Roles criticos (equivalente al
    flag 'S_TABU_DIS=*' del original)."""

    __tablename__ = "sap_role_table_auth"

    id = db.Column(db.Integer, primary_key=True)
    role_name = db.Column(db.String(80), unique=True, nullable=False, index=True)
    imported_at = db.Column(db.DateTime, default=datetime.utcnow)


class SapTcodeDescription(db.Model):
    """Descripcion corta de cada transaccion SAP, importada de TSTCT.xlsx
    (solo informativa: se usa como tooltip/columna en Roles criticos y en
    la Matriz Usuario x Rol x TCode)."""

    __tablename__ = "sap_tcode_descriptions"

    id = db.Column(db.Integer, primary_key=True)
    tcode = db.Column(db.String(40), unique=True, nullable=False, index=True)
    description = db.Column(db.String(255), default="")
    imported_at = db.Column(db.DateTime, default=datetime.utcnow)


class SodRule(db.Model):
    """Regla de la matriz SOD (conflicto entre dos grupos de transacciones).

    Se siembra con las reglas base de SAP_SOD_Analyzer_v640.html (ver
    app/sod/rules_data.py) y puede editarse/desactivarse/ampliarse desde
    la UI sin tocar codigo -- igual que la tabla SOD_REGLAS del original.
    """

    __tablename__ = "sod_rules"

    id = db.Column(db.String(20), primary_key=True)  # ej. 'MM-001'
    modulo = db.Column(db.String(10), default="")
    nivel = db.Column(db.String(10), nullable=False)  # CRITICO | ALTO | MEDIO
    descripcion = db.Column(db.String(255), nullable=False)
    permiso1 = db.Column(db.String(120), default="")
    tcodes1 = db.Column(db.Text, default="[]")  # lista JSON de tcodes lado A
    permiso2 = db.Column(db.String(120), default="")
    tcodes2 = db.Column(db.Text, default="[]")  # lista JSON de tcodes lado B
    activo = db.Column(db.Boolean, default=True)
    origen = db.Column(db.String(20), default="BASE")  # BASE | CUSTOM
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def tcodes1_list(self):
        return json.loads(self.tcodes1 or "[]")

    def tcodes2_list(self):
        return json.loads(self.tcodes2 or "[]")

    def set_tcodes1(self, codes):
        self.tcodes1 = json.dumps([c.strip().upper() for c in codes