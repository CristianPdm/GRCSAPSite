import csv
import io
import json
from datetime import datetime

import openpyxl
from flask import flash, jsonify, redirect, render_template, request, url_for, Response
from flask_login import current_user, login_required

from app.decorators import permission_required
from app.extensions import db
from app.models import AppSetting, AuditLog
from app.sod import bp
from app.utils.sap_import import SAP_IMPORT_FOLDER_SETTING, scan_import_folder
from app.sod.docx_export import build_informe_docx
from app.sod.engine import (
    build_audit_report_data,
    build_maps,
    build_matrix_rows,
    build_role_crit,
    build_user_risk,
    get_sod_summary,
    run_analysis,
    validate_new_role,
)
from app.sod.importers import (
    import_agr_1251,
    import_agr_define,
    import_agr_tcodes,
    import_agr_users,
    import_tstct,
)
from app.sod.models import (
    SapRoleAssignment,
    SapRoleTableAuth,
    SapRoleTcode,
    SapTcodeDescription,
    SodException,
    SodRule,
)
from app.sod.rules_data import SOD_BASE_RULES


@bp.route("/")
@login_required
@permission_required("can_view_sod")
def index():
    """Punto de entrada del modulo SOD/GRC: resumen + accesos a las
    distintas pantallas (importacion, resultados, reglas, excepciones)."""
    permissions = {
        "puede_ejecutar_analisis": current_user.has_permission("can_run_sod_analysis"),
        "puede_administrar_config": current_user.has_permission("can_manage_sod_config"),
        "puede_exportar": current_user.has_permission("can_export_reports"),
    }
    summary = get_sod_summary()
    return render_template("sod/index.html", permissions=permissions, summary=summary)


@bp.route("/importar", methods=["GET", "POST"])
@login_required
@permission_required("can_manage_sod_config", "can_import_sap_data")
def importar():
    """Carga de archivos Excel exportados de SAP (AGR_USERS, AGR_1251,
    AGR_TCODES, AGR_DEFINE). Cada carga reemplaza por completo los datos
    previos de esa tabla (full refresh), igual que el importador original.

    Ademas de subir cada archivo a mano, se puede configurar una carpeta del
    servidor donde se dejan todos los Excel y disparar una importacion en
    lote que los detecta por nombre (ver app/utils/sap_import.py)."""
    importers = {
        "AGR_USERS": ("Asignaciones Rol-Usuario", import_agr_users),
        "AGR_1251": ("Transacciones por rol (S_TCODE)", import_agr_1251),
        "AGR_TCODES": ("Transacciones por rol (respaldo)", import_agr_tcodes),
        "AGR_DEFINE": ("Descripciones de rol", import_agr_define),
        "TSTCT": ("Descripciones de TCode (opcional)", import_tstct),
    }

    scan_resultado = None

    if request.method == "POST":
        accion = request.form.get("accion", "subir_archivo")

        if accion == "guardar_carpeta":
            carpeta = request.form.get("carpeta", "").strip()
            AppSetting.set(SAP_IMPORT_FOLDER_SETTING, carpeta)
            AuditLog.log("sap_import_folder_set", username=current_user.username,
                         details=f"Carpeta de importacion SAP: {carpeta or '(vacia)'}")
            flash("Carpeta de importación guardada." if carpeta else "Carpeta de importación borrada.", "success")
            return redirect(url_for("sod.importar"))

        if accion == "importar_carpeta":
            carpeta = AppSetting.get(SAP_IMPORT_FOLDER_SETTING, "")
            scan_resultado = scan_import_folder(carpeta, importers)

            if scan_resultado is None:
                flash("La carpeta configurada no existe o no es accesible desde el servidor.", "error")
            else:
                for item in scan_resultado:
                    if item["ok"]:
                        AuditLog.log("sod_import", username=current_user.username,
                                     details=f"{item['tipo']}: {item['count']} filas importadas ({item['filename']}, vía carpeta)")

                ok_count = sum(1 for item in scan_resultado if item["ok"])
                err_count = sum(1 for item in scan_resultado if item["found"] and not item["ok"])
                missing_count = sum(1 for item in scan_resultado if not item["found"])

                if ok_count:
                    flash(f"{ok_count} archivo(s) importado(s) correctamente desde la carpeta.", "success")
                if err_count:
                    flash(f"{err_count} archivo(s) encontrados con errores al importar (ver detalle abajo).", "error")
                if missing_count:
                    flash(f"{missing_count} archivo(s) esperados no se encontraron en la carpeta.", "warning")
        else:
            tipo = request.form.get("tipo")
            archivo = request.files.get("archivo")

            if not archivo or not archivo.filename:
                flash("Selecciona un archivo .xlsx para importar.", "error")
                return redirect(url_for("sod.importar"))

            if tipo not in importers:
                flash("Tipo de archivo no reconocido.", "error")
                return redirect(url_for("sod.importar"))

            label, importer_func = importers[tipo]
            try:
                count = importer_func(archivo.stream)
            except Exception as exc:
                flash(f"Error al importar {label}: {exc}", "error")
                return redirect(url_for("sod.importar"))

            AuditLog.log("sod_import", username=current_user.username,
                         details=f"{tipo}: {count} filas importadas ({archivo.filename})")
            flash(f"{label}: {count} filas importadas correctamente.", "success")
            return redirect(url_for("sod.importar"))

    stats = {
        "agr_users": SapRoleAssignment.query.count(),
        "agr_1251": SapRoleTcode.query.filter_by(source="AGR_1251").count(),
        "agr_tcodes": SapRoleTcode.query.filter_by(source="AGR_TCODES").count(),
        "tabu_dis": SapRoleTableAuth.query.count(),
        "tstct": SapTcodeDescription.query.count(),
    }
    carpeta = AppSetting.get(SAP_IMPORT_FOLDER_SETTING, "")
    return render_template("sod/import.html", stats=stats, carpeta=carpeta, scan_resultado=scan_resultado)


@bp.route("/resultados")
@login_required
@permission_required("can_view_sod")
def resultados():
    """Resultados del analisis SOD: conflictos activos por regla, agrupados
    por nivel de severidad. Se recalcula en cada visita (no se persiste el
    resultado, solo las reglas/excepciones que lo determinan)."""
    results = run_analysis()
    modulos = sorted({item["rule"].modulo for item in results if item["rule"].modulo})
    return render_template("sod/results.html", results=results, modulos=modulos)


@bp.route("/resultados/exportar.csv")
@login_required
@permission_required("can_export_reports")
@permission_required("can_view_sod")
def exportar_resultados():
    """Exporta los conflictos activos (no exceptuados) a CSV. Requiere
    ademas can_view_sod (no solo can_export_reports): solo se puede
    exportar lo que tambien se tiene permiso de ver en pantalla (/resultados)."""
    results = run_analysis()

    buffer = io.StringIO()
    writer = csv.writer(buffer)
    writer.writerow(["Regla", "Modulo", "Nivel", "Descripcion", "Usuario"])
    for item in results:
        rule = item["rule"]
        for username in item["conflicted_users"]:
            writer.writerow([rule.id, rule.modulo, rule.nivel, rule.descripcion, username])

    return Response(
        buffer.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment; filename=sod_conflictos.csv"},
    )


@bp.route("/usuarios-riesgo")
@login_required
@permission_required("can_view_sod")
def usuarios_riesgo():
    """Vista por usuario: conflictos SOD, FUE derivado de sus roles y (si
    hay datos de Licencias importados) FUE oficial e inactividad SAP."""
    rows = build_user_risk()
    return render_template("sod/usuarios_riesgo.html", rows=rows)


@bp.route("/roles-criticos")
@login_required
@permission_required("can_view_sod")
def roles_criticos():
    """Vista por rol: severidad SOD, FUE de referencia, usuarios
    asignados, tcodes y bandera de acceso irrestricto a tablas."""
    rows = build_role_crit()
    return render_template("sod/roles_criticos.html", rows=rows)


@bp.route("/validar", methods=["GET", "POST"])
@login_required
@permission_required("can_view_sod")
def validar():
    """Simulador 'Validar nuevo rol': antes de asignar roles nuevos a un
    usuario en SAP, simula el efecto sobre los conflictos SOD y el tipo
    FUE resultante, y devuelve una recomendacion (RECHAZAR / EXCEPCION
    DOCUMENTADA / REVISAR FUE / APROBAR)."""
    _, r2u = build_maps()
    usuarios_conocidos = sorted({u for users in r2u.values() for u in users})

    resultado = None
    username_in = ""
    roles_in = ""
    if request.method == "POST":
        username_in = request.form.get("username", "").strip()
        roles_in = request.form.get("roles", "")
        roles_list = [r for r in roles_in.split(",") if r.strip()]
        if not username_in or not roles_list:
            flash("Indica el usuario y al menos un rol nuevo a simular.", "error")
        else:
            resultado = validate_new_role(username_in, roles_list)

    return render_template(
        "sod/validar.html",
        usuarios_conocidos=usuarios_conocidos,
        resultado=resultado,
        username_in=username_in,
        roles_in=roles_in,
    )


@bp.route("/validar/roles.json")
@login_required
@permission_required("can_view_sod")
def validar_roles_json():
    """Lista de roles conocidos (asignados y/o con tcodes) para el picker
    del simulador de validacion de nuevo rol."""
    _, r2u = build_maps()
    role_tcodes_roles = {row[0] for row in db.session.query(SapRoleTcode.role_name).distinct()}
    return jsonify(sorted(set(r2u.keys()) | role_tcodes_roles))


@bp.route("/matriz")
@login_required
@permission_required("can_view_sod")
def matriz():
    """Matriz Usuario x Rol x TCode: una fila por cada tcode habilitado de
    cada rol activo de cada usuario. Filtros por substring o wildcard (*, ?)
    (usuario, rol, tcode) via query string, aplicados en el servidor; la
    vista se limita a las primeras 2000 filas del resultado filtrado
    (igual que el original, que truncaba la tabla en el navegador).
    Si la request viene de matrix-filters.js (busqueda incremental, header
    X-Requested-With) se devuelve solo el fragmento de resultados en vez
    de la pagina completa, para actualizar la tabla sin re