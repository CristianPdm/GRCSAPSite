"""Motor de analisis de Segregacion de Funciones (SOD).

Reproduce la logica de SAP_SOD_Analyzer_v640.html: cruza Rol->Transaccion
(tc2r) con Usuario->Rol (r2u) para encontrar, por cada regla activa, los
usuarios que tienen acceso a AMBOS lados del conflicto. Las excepciones
vigentes (SodException) se restan del conteo de conflictos activos.
"""
import fnmatch
from collections import defaultdict
from datetime import date

from app.sod.models import (
    SapRoleAssignment,
    SapRoleDescription,
    SapRoleTableAuth,
    SapRoleTcode,
    SapTcodeDescription,
    SodException,
    SodRule,
)


def build_maps():
    """Construye (tc2r, r2u):
      tc2r: tcode -> set(roles) que la habilitan (AGR_1251 + AGR_TCODES, sin duplicar)
      r2u:  role -> set(usuarios) con asignacion vigente (Fecha fin vacia o futura)
    """
    tc2r = defaultdict(set)
    for row in SapRoleTcode.query.all():
        tc2r[row.tcode].add(row.role_name)

    today = date.today()
    r2u = defaultdict(set)
    for row in SapRoleAssignment.query.all():
        if row.valid_to and row.valid_to < today:
            continue
        r2u[row.role_name].add(row.username)

    return tc2r, r2u


def _users_for_tcodes(tcodes, tc2r, r2u):
    roles = set()
    for tcode in tcodes:
        roles |= tc2r.get(tcode, set())
    users = set()
    for role in roles:
        users |= r2u.get(role, set())
    return users


def run_analysis():
    """Ejecuta el analisis sobre todas las reglas activas.

    Devuelve una lista de dicts:
      {rule: SodRule, conflicted_users: [str], excepted_users: [str], active_count: int}
    ordenada por nivel de severidad (CRITICO > ALTO > MEDIO) y luego por id.
    """
    tc2r, r2u = build_maps()

    severity_order = {"CRITICO": 0, "ALTO": 1, "MEDIO": 2}
    rules = SodRule.query.filter_by(activo=True).all()

    exceptions_by_rule = defaultdict(set)
    for exc in SodException.query.all():
        exceptions_by_rule[exc.regla_id].add(exc.usuario)

    results = []
    for rule in rules:
        users1 = _users_for_tcodes(rule.tcodes1_list(), tc2r, r2u)
        users2 = _users_for_tcodes(rule.tcodes2_list(), tc2r, r2u)
        conflicted = users1 & users2

        excepted_set = exceptions_by_rule.get(rule.id, set())
        active_conflicted = sorted(conflicted - excepted_set)
        excepted_conflicted = sorted(conflicted & excepted_set)

        results.append({
            "rule": rule,
            "conflicted_users": active_conflicted,
            "excepted_users": excepted_conflicted,
            "active_count": len(active_conflicted),
        })

    results.sort(key=lambda r: (severity_order.get(r["rule"].nivel, 9), r["rule"].id))
    return results


def count_inactive_at_risk(analysis_results, inactivity_days=90):
    """Cuenta usuarios con conflicto activo cuyo ultimo acceso SAP (segun el
    modulo de Licencias, FUE_Users.xlsx) supera `inactivity_days`. Devuelve 0
    si todavia no se importaron datos de licencias -- la dependencia es
    opcional y unidireccional (SOD lee de Licencias, nunca al reves)."""
    try:
        from app.licenses.models import LicenseUser
    except ImportError:
        return 0

    last_access_by_user = {
        u.username: u.last_access for u in LicenseUser.query.all() if u.last_access
    }
    if not last_access_by_user:
        return 0

    today = date.today()
    at_risk_users = set()
    for item in analysis_results:
        for username in item["conflicted_users"]:
            last_access = last_access_by_user.get(username)
            if last_access and (today - last_access).days > inactivity_days:
                at_risk_users.add(username)

    return len(at_risk_users)


def get_sod_summary():
    """Resumen para el tile del dashboard y el encabezado de resultados.

    Nombres de campo (`critical`/`high`/`medium`/`active_users`/
    `at_risk_inactive`) elegidos para coincidir exactamente con lo que
    espera templates/main/dashboard.html."""
    has_data = SapRoleAssignment.query.first() is not None and SapRoleTcode.query.first() is not None

    # Reglas activas por modulo SAP: util para ver donde esta concentrada la
    # matriz, independientemente de si ya se importaron datos de roles/usuarios.
    rules_by_module_counts = defaultdict(int)
    for rule in SodRule.query.filter_by(activo=True).all():
        rules_by_module_counts[rule.modulo] += 1
    rules_by_module = sorted(
        ({"modulo": m, "count": c} for m, c in rules_by_module_counts.items()),
        key=lambda x: -x["count"],
    )

    if not has_data:
        return {
            "has_data": False,
            "total_rules": SodRule.query.filter_by(activo=True).count(),
            "critical": 0,
            "high": 0,
            "medium": 0,
            "active_users": 0,
            "exceptions": SodException.query.count(),
            "at_risk_inactive": 0,
            "rules_by_module": rules_by_module,
            "modulo_breakdown": [],
            "top_rules": [],
        }

    results = run_analysis()
    critical = sum(r["active_count"] for r in results if r["rule"].nivel == "CRITICO")
    high = sum(r["active_count"] for r in results if r["rule"].nivel == "ALTO")
    medium = sum(r["active_count"] for r in results if r["rule"].nivel == "MEDIO")

    active_users = set()
    for r in results:
        active_users.update(r["conflicted_users"])

    # Conflictos activos agrupados por modulo SAP (para el grafico de barras
    # "Conflictos por modulo") y el top 5 de reglas con mas usuarios en
    # conflicto (para priorizar que reglas atacar primero).
    modulo_counts = defaultdict(int)
    for r in results:
        if r["active_count"] > 0:
            modulo_counts[r["rule"].modulo] += r["active_count"]
    modulo_breakdown = sorted(
        ({"modulo": m, "count": c} for m, c in modulo_counts.items()),
        key=lambda x: -x["count"],
    )

    top_rules = sorted(
        (r for r in results if r["active_count"] > 0),
        key=lambda r: -r["active_count"],
    )[:5]
    top_rules = [
        {
            "id": r["rule"].id,
            "descripcion": r["rule"].descripcion,
            "nivel": r["rule"].nivel,
            "modulo": r["rule"].modulo,
            "active_count": r["active_count"],
        }
        for r in top_rules
    ]

    return {
        "has_data": True,
        "total_rules": len(results),
        "critical": critical,
        "high": high,
        "medium": medium,
        "active_users": len(active_users),
        "exceptions": SodException.query.count(),
        "at_risk_inactive": count_inactive_at_risk(results),
        "rules_by_module": rules_by_module,
        "modulo_breakdown": modulo_breakdown,
        "top_rules": top_rules,
    }


def _license_data():
    """Devuelve (license_users_por_usuario, license_roles_por_nombre).
    Lectura opcional y unidireccional: SOD lee de Licencias, nunca al
    reves. Si el modulo de Licencias todavia no tiene datos importados
    (o ni siquiera esta disponible), devuelve diccionarios vacios."""
    try:
        from app.licenses.models import LicenseRole, LicenseUser
    except ImportError:
        return {}, {}

    users = {u.username: u for u in LicenseUser.query.all()}
    roles = {r.role_name: r for r in LicenseRole.query.all()}
    return users, roles


def _user_to_roles_map(r2u):
    """Invierte r2u (rol -> usuarios) a usuario -> set(roles)."""
    user_to_roles = defaultdict(set)
    for role, users in r2u.items():
        for username in users:
            user_to_roles[username].add(role)
    return user_to_roles


def _role_tcode_map():
    """rol -> set(tcodes) que habilita, sin importar la fuente
    (AGR_1251/AGR_TCODES, ya fusionadas en SapRoleTcode)."""
    m = defaultdict(set)
    for row in SapRoleTcode.query.all():
        m[row.role_name].add(row.tcode)
    return m


def _matches(value, filtro):
    """Coincidencia de un filtro de texto contra un valor, insensible a
    mayusculas. Si el filtro contiene * o ?, se interpreta como patron
    wildcard (estilo SAP: * = cualquier cadena, ? = un caracter) aplicado
    al valor completo. Si no tiene wildcards, se usa busqueda por
    substring ("contiene"), igual que antes -- asi la busqueda incremental
    (letra por letra) sigue funcionando de forma intuitiva sin necesidad
    de escribir asteriscos."""
    if not filtro:
        return True
    value = value.lower()
    if "*" in filtro or "?" in filtro:
        return fnmatch.fnmatch(value, filtro)
    return filtro in value


def build_matrix_rows(f_user="", f_rol="", f_tc=""):
    """Equivalente a S.matrixRows + rMX() del original: una fila por cada
    combinacion (usuario, rol, tcode) -- el usuario tiene el rol asignado
    (activo) y el rol habilita ese tcode -- con la descripcion del tcode
    (TSTCT) si esta importada. Los filtros admiten substring simple o
    wildcards (*, ?), insensibles a mayusculas (ver _matches), aplicados
    del lado del servidor (a diferencia del original, que cargaba todas
    las filas en el navegador y filtraba ahi; con datos reales esta
    matriz puede tener decenas de miles de filas)."""
    _, r2u = build_maps()
    user_to_roles = _user_to_roles_map(r2u)
    role_tcodes = _role_tcode_map()
    tcode_desc = {d.tcode: d.description for d in SapTcodeDescription.query.all()}

    f_user = (f_user or "").strip().lower()
    f_rol = (f_rol or "").strip().lower()
    f_tc = (f_tc or "").strip().lower()

    rows = []
    for username, roles in user_to_roles.items():
        if not _matches(username, f_user):
            continue
        for role_name in sorted(roles):
            if not _matches(role_name, f_rol):
                continue
            for tcode in sorted(role_tcodes.get(role_name, set())):
                if not _matches(tcode, f_tc):
                    continue
                rows.append({
                    "user": username,
                    "rol": role_name,
                    "tc": tcode,
                    "desc": tcode_desc.get(tcode, ""),
                })

    rows.sort(key=lambda r: (r["user"], r["rol"], r["tc"]))
    return rows


def build_user_risk():
    """Equivalente a S.userRisk del original: un registro por usuario con
    al menos un rol activo, cruzando sus conflictos SOD con el FUE
    derivado de sus roles y (si hay datos importados) el FUE oficial SAP
    y la inactividad, leidos del modulo de Licencias."""
    from app.licenses.rules import FUE_LABEL, FUE_ORDER, FUE_WEIGHT

    _, r2u = build_maps()
    results = run_analysis()
    user_to_roles = _user_to_roles_map(r2u)
    license_users, license_roles = _license_data()

    severity_rank = {"CRITICO": 0, "ALTO": 1, "MEDIO": 2}
    conflicts_by_user = defaultdict(list)
    niveles_by_user = defaultdict(set)
    for item in results:
        rule = item["rule"]
        for username in item["conflicted_users"]:
            conflicts_by_user[username].append(rule.id)
            niveles_by_user[username].add(rule.nivel)

    today = date.today()
    rows = []
    for username, roles in user_to_roles.items():
        role_fue_order = 0
        role_fue_code = "NONE"
        fue_roles = []
        for role_name in sorted(roles):
            lic_role = license_roles.get(role_name)
            code = lic_role.fue_type_code if lic_role else "NONE"
            if lic_role and code != "NONE":
                fue_roles.append({"rol": role_name, "type": code, "label": FUE_LABEL[code]})
            if FUE_ORDER.get(code, 0) > role_fue_order:
                role_fue_order = FUE_ORDER.get(code, 0)
                role_fue_code = code

        niveles = niveles_by_user.get(username, set())
        if "CRITICO" in niveles:
            mx = "CRITICO"
        elif "ALTO" in niveles:
            mx = "ALTO"
        elif niveles:
            mx = "MEDIO"
        else:
            mx = "SIN"

        lic_user = license_users.get(username)
        last_access = lic_user.last_access if lic_user else None
        days = (today - last_access).days if last_access else None

        rows.append({
            "user": username,
            "nombre": lic_user.full_name if lic_user else "",
            "role_count": len(roles),
            "cc": len(conflicts_by_user.get(username, [])),
            "conflicts": conflicts_by_user.get(username, []),
            "mx": mx,
            "fue_type": role_fue_code,
            "fue_label": FUE_LABEL[role_fue_code],
            "fue_weight": FUE_WEIGHT[role_fue_code],
            "fue_roles": fue_roles,
            "fue_from_db_code": lic_user.fue_type_code if lic_user else None,
            "fue_from_db_label": FUE_LABEL.get(lic_user.fue_type_code, "Sin tipo FUE") if lic_user else None,
            "indice_fue": lic_user.indice_fue if lic_user else "",
            "last_access": last_access,
            "days": days,
            "has_license_data": lic_user is not None,
        })

    rows.sort(key=lambda r: (severity_rank.get(r["mx"], 9), -r["cc"], r["user"]))
    return rows


def build_role_crit():
    """Equivalente a S.roleCrit del original: un registro por rol
    involucrado en al menos un conflicto SOD (roles que habilitan ambos
    lados de alguna regla activa) o con la bandera S_TABU_DIS=*, con su
    FUE de referencia, usuarios asignados y tcodes."""
    from app.licenses.rules import FUE_LABEL

    tc2r, r2u = build_maps()
    rules = SodRule.query.filter_by(activo=True).all()
    role_tcodes = _role_tcode_map()
    role_descriptions = {d.role_name: d.description for d in SapRoleDescription.query.all()}
    tabu_dis_roles = {row.role_name for row in SapRoleTableAuth.query.all()}
    _, license_roles = _license_data()

    rcm = defaultdict(lambda: {"ids": [], "niveles": set()})
    for rule in rules:
        roles1, roles2 = set(), set()
        for tcode in rule.tcodes1_list():
            roles1 |= tc2r.get(tcode, set())
        for tcode in rule.tcodes2_list():
            roles2 |= tc2r.get(tcode, set())
        if not roles1 or not roles2:
            continue
        for role_name in roles1 & roles2:
            rcm[role_name]["ids"].append(rule.id)
            rcm[role_name]["niveles"].add(rule.nivel)

    for role_name in tabu_dis_roles:
        rcm[role_name]["ids"].append("S_TABU_DIS=*")
        rcm[role_name]["niveles"].add("ALTO")

    severity_rank = {"CRITICO": 0, "ALTO": 1, "MEDIO": 2}
    rows = []
    for role_name in set(r2u.keys()) | set(rcm.keys()):
        info = rcm.get(role_name)
        niveles = info["niveles"] if info else set()
        if "CRITICO" in niveles:
            mx = "CRITICO"
        elif "ALTO" in niveles:
            mx = "ALTO"
        elif niveles:
            mx = "MEDIO"
        else:
            mx = "SIN"

        lic_role = license_roles.get(role_name)
        role_tcs = sorted(role_tcodes.get(role_name, set()))
        rows.append({
            "rol": role_name,
            "mx": mx,
            "ids": info["ids"] if info else [],
            "tabu_dis": role_name in tabu_dis_roles,
            "uc": len(r2u.get(role_name, set())),
            "users": sorted(r2u.get(role_name, set())),
            "tcs": role_tcs[:10],
            "tcs_total": len(role_tcs),
            "desc": role_descriptions.get(role_name, "") or (lic_role.description if lic_role else ""),
            "fue_code": lic_role.fue_type_code if lic_role else None,
            "fue_label": FUE_LABEL.get(lic_role.fue_type_code) if lic_role else None,
            "fue_ratio": lic_role.ratio if lic_role else "",
        })

    rows.sort(key=lambda r: (severity_rank.get(r["mx"], 9), -r["uc"], r["rol"]))
    return rows


def validate_new_role(username, new_role_names):
    """Equivalente a runVal() del original: simula el efecto de asignarle a
    `username` los roles en `new_role_names`, ademas de los que ya tiene
    activos, ANTES de ejecutar la asignacion real en SAP.

    Diferencia deliberada con el original: los roles "actuales" del usuario
    se toman de r2u (solo asignaciones activas, via build_maps()), en vez
    de todas las filas crudas de AGR_USERS sin filtrar por fecha de
    vencimiento -- es la opcion consistente con el resto del motor
    (build_user_risk()/build_role_crit()).

    Un conflicto se cuenta como "nuevo" si la regla queda cubierta por
    ambos lados (como en run_analysis()) Y al menos uno de esos lados solo
    queda cubierto gracias a un tcode que aportan los roles nuevos (no lo
    tenia ya por sus roles actuales). Asi se detectan tanto conflictos
    ineditos como conflictos ya existentes que los roles nuevos refuerzan.
    """
    from app.licenses.rules import FUE_LABEL, FUE_ORDER

    tc2r, r2u = build_maps()
    role_tcodes = _role_tcode_map()
    _, license_roles = _license_data()
    role_descriptions = {d.role_name: d.description for d in SapRoleDescription.query.all()}
    known_roles = set(role_tcodes.keys()) | set(r2u.keys())

    username = (username or "").strip().upper()
    new_roles = sorted({r.strip() for r in new_role_names if r and r.strip()})

    current_roles = sorted(role for role, users in r2u.items() if username in users)

    tc_curr = set()
    for role in current_roles:
        tc_curr |= role_tcodes.get(role, set())
    tc_all_new = set()
    for role in new_roles:
        tc_all_new |= role_tcodes.get(role, set())
    tc_neto = tc_all_new - tc_curr
    tc_total = tc_curr | tc_all_new

    new_conflicts = []
    rules = SodRule.query.filter_by(activo=True).all()
    for rule in rules:
        t1 = rule.tcodes1_list()
        t2 = rule.tcodes2_list()
        has_a = any(tc in tc_total for tc in t1)
        has_b = any(tc in tc_total for tc in t2)
        net_a = any(tc in tc_neto for tc in t1)
        net_b = any(tc in tc_neto for tc in t2)
        if has_a and has_b and (net_a or net_b):
            sides = t1 + t2
            contributions = []
            for role in new_roles:
                rtc = role_tcodes.get(role, set())
                aporte = sorted({tc for tc in sides if tc in rtc and tc not in tc_curr})
                if aporte:
                    contributions.append({"rol": role, "tcodes": aporte})
            new_conflicts.append({"rule": rule, "from_new_roles": contributions})

    def role_fue_code(role_name):
        lic = license_roles.get(role_name)
        return lic.fue_type_code if lic else "NONE"

    cur_fue_order, cur_fue_code = 0, "NONE"
    for role in current_roles:
        code = role_fue_code(role)
        if FUE_ORDER.get(code, 0) > cur_fue_order:
            cur_fue_order, cur_fue_code = FUE_ORDER.get(code, 0), code

    result_fue_order, result_fue_code = cur_fue_order, cur_fue_code
    new_roles_info = []
    for role in new_roles:
        code = role_fue_code(role)
        if FUE_ORDER.get(code, 0) > result_fue_order:
            result_fue_order, result_fue_code = FUE_ORDER.get(code, 0), code
        new_roles_info.append({
            "rol": role,
            "desc": role_descriptions.get(role, ""),
            "fue_code": code,
            "fue_label": FUE_LABEL.get(code, "Sin tipo FUE"),
            "known": role in known_roles,
        })

    upgrade = result_fue_order > cur_fue_order

    niveles = {item["rule"].nivel for item in new_conflicts}
    if "CRITICO" in niveles or "ALTO" in niveles:
        decision = "RECHAZAR"
    elif "MEDIO" in niveles:
        decision = "EXCEPCION_DOCUMENTADA"
    elif upgrade:
        decision = "REVISAR_FUE"
    else:
        decision = "APROBAR"

    return {
        "username": username,
        "current_roles": current_roles,
        "new_roles": new_roles,
        "new_roles_info": new_roles_info,
        "new_conflicts": new_conflicts,
        "tc_neto_count": len(tc_neto),
        "tc_total_count": len(tc_total),
        "current_fue_code": cur_fue_code,
        "current_fue_label": FUE_LABEL.get(cur_fue_code, "Sin tipo FUE"),
        "result_fue_code": result_fue_code,
        "result_fue_label": FUE_LABEL.get(result_fue_code, "Sin tipo FUE"),
        "upgrade": upgrade,
        "decision": decision,
    }


def build_audit_report_data():
    """Datos para el Informe de Auditoria GRC-SOD (equivalente a expReport()
    de SAP_SOD_Analyzer_v640.html). Reutiliza get_sod_summary(), run_analysis(),
    build_user_risk() y build_role_crit() -- no recalcula nada que ya exista.

    El desglose FUE (fue_stats/fue_top_rows) se toma del resumen oficial del
    modulo de Licencias (FUE_Users.xlsx, via get_license_summary()) cuando
    hay datos importados; si no, se deriva de build_user_risk() (FUE segun
    roles asignados), igual que hacia el original cuando no tenia S.fueMeta.
    """
    from app.licenses.engine import get_license_summary

    summary = get_sod_summary()
    results = run_analysis()
    user_risk = build_user_risk()
    role_crit = build_role_crit()

    _, r2u = build_maps()
    total_usuarios_activos = len({u for users in r2u.values() for u in users})
    total_roles_en_uso = len(r2u)

    license_summary = get_license_summary()
    fue_source_oficial = license_summary["has_data"]
    if fue_source_oficial:
        from app.licenses.rules import FUE_WEIGHT

        fue_stats = {
            "ADV": license_summary["advanced"],
            "CORE": license_summary["core"],
            "SELF": license_summary["self_service"],
            "total_fue": license_summary["total_fue"],
        }
        fue_top_rows = [
            {
                "user": u["user"],
                "nombre": u["nombre"],
                "fue_code": u["fue_from_db_code"],
                "fue_label": u["fue_from_db_label"],
                "fue_weight": FUE_WEIGHT.get(u["fue_from_db_code"], 0.0),
                "last_access": u["last_access"],
            }
            for u in user_risk
            if u["fue_from_db_code"] in ("ADV", "CORE", "SELF")
        ]
    else:
        adv = sum(1 for u in user_risk if u["fue_type"] == "ADV")
        core = sum(1 for u in user_risk if u["fue_type"] == "CORE")
        selfsvc = sum(1 for u in user_risk if u["fue_type"] == "SELF")
        fue_stats = {
            "ADV": adv,
            "CORE": core,
            "SELF": selfsvc,
            "total_fue": round(sum(u["fue_weight"] for u in user_risk), 2),
        }
        fue_top_rows = [
            {
                "user": u["user"],
                "fue_code": u["fue_type"],
                "fue_label": u["fue_label"],
                "fue_weight": u["fue_weight"],
                "fue_roles": u["fue_roles"],
            }
            for u in user_risk
            if u["fue_type"] != "NONE"
        ]
    fue_top_rows.sort(key=lambda r: -r["fue_weight"])
    fue_top_rows = fue_top_rows[:60]

    # "roles involucrados" por regla: los mismos roles que build_role_crit()
    # ya identifica como causantes de cada conflicto (rcm[role]["ids"]),
    # invertidos a regla -> [roles].
    roles_by_rule_id = defaultdict(list)
    for r in role_crit:
        for rule_id in r["ids"]:
            roles_by_rule_id[rule_id].append(r["rol"])

    rules_with_conflict = [r for r in results if r["conflicted_users"] or r["excepted_users"]]
    rules_active = [r for r in rules_with_conflict if r["active_count"] > 0]
    rules_fully_excepted = [r for r in rules_with_conflict if r["active_count"] == 0]

    criticos_activos = [r for r in rules_active if r["rule"].nivel == "CRITICO"]
    altos_activos = [r for r in rules_active if r["rule"].nivel == "ALTO"]
    medios_activos = [r for r in rules_active if r["rule"].nivel == "MEDIO"]

    modulos = sorted({r["rule"].modulo for r in rules_active})
    modulo_breakdown = []
    for modulo in modulos:
        items = [r for r in rules_active if r["rule"].modulo == modulo]
        modulo_breakdown.append({
            "modulo": modulo,
            "critico": sum(1 for r in items if r["rule"].nivel == "CRITICO"),
            "alto": sum(1 for r in items if r["rule"].nivel == "ALTO"),
            "medio": sum(1 for r in items if r["rule"].nivel == "MEDIO"),
            "total": len(items),
        })

    users_en_riesgo_all = [u for u in user_risk if u["cc"] > 0]
    roles_criticos_count = sum(1 for r in role_crit if r["mx"] == "CRITICO")

    hits_by_rule = {
        r["rule"].id: len(r["conflicted_users"]) + len(r["excepted_users"])
        for r in results
    }
    todas_las_reglas = SodRule.query.order_by(SodRule.id).all()

    return {
        "summary": summary,
        "fue_stats": fue_stats,
        "fue_source_oficial": fue_source_oficial,
        "fue_top_rows": fue_top_rows,
        "total_usuarios_activos": total_usuarios_activos,
        "total_roles_en_uso": total_roles_en_uso,
        "users_en_riesgo": users_en_riesgo_all[:50],
        "users_en_riesgo_total": len(users_en_riesgo_all),
        "roles_criticos": role_crit[:60],
        "roles_criticos_total": len(role_crit),
        "roles_criticos_count": roles_criticos_count,
        "modulo_breakdown": modulo_breakdown,
        "criticos_activos": criticos_activos,
        "altos_activos": altos_activos,
        "medios_activos": medios_activos,
        "rules_active_count": len(rules_active),
        "rules_fully_excepted_count": len(rules_fully_excepted),
        "roles_by_rule_id": dict(roles_by_rule_id),
        "todas_las_reglas": todas_las_reglas,
        "hits_by_rule": hits_by_rule,
        "total_rules_count": SodRule.query.count(),
    }
