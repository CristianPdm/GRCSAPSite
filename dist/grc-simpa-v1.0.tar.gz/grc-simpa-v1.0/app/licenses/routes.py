from datetime import date

from flask import flash, redirect, render_template, request, url_for
from flask_login import current_user, login_required

from app.decorators import permission_required
from app.licenses import bp
from app.licenses.engine import build_fue_comparison, compute_fue_optimization, get_license_summary
from app.licenses.importers import import_fue_roles, import_fue_users
from app.licenses.models import LicenseRole, LicenseUser
from app.licenses.rules import FUE_LABEL, INACTIVITY_THRESHOLD_DAYS
from app.models import AppSetting, AuditLog
from app.utils.sap_import import SAP_IMPORT_FOLDER_SETTING, scan_import_folder


@bp.route("/")
@login_required
@permission_required("can_view_licenses")
def index():
    """Punto de entrada del modulo de Licencias SAP: resumen de consumo de
    FUEs y accesos a importacion / listado de usuarios."""
    puede_administrar = current_user.has_permission("can_manage_licenses")
    summary = get_license_summary()
    return render_template("licenses/index.html", puede_administrar=puede_administrar, summary=summary)


@bp.route("/importar", methods=["GET", "POST"])
@login_required
@permission_required("can_manage_licenses", "can_import_sap_data")
def importar():
    """Carga de FUE_Rol.xlsx y FUE_Users.xlsx. FUE_Users.xlsx es la fuente
    canonica del calculo de licencias; FUE_Rol.xlsx queda como referencia.

    Tambien admite importar ambos desde una carpeta configurable del
    servidor (la misma que usa el modulo SOD), detectando los archivos por
    nombre en lugar de subirlos de a uno (ver app/utils/sap_import.py)."""
    importers = {
        "FUE_ROL": ("Tipo FUE por rol", import_fue_roles),
        "FUE_USERS": ("Tipo FUE oficial por usuario", import_fue_users),
    }

    scan_resultado = None

    if request.method == "POST":
        accion = request.form.get("accion", "subir_archivo")

        if accion == "guardar_carpeta":
            carpeta = request.form.get("carpeta", "").strip()
            AppSetting.set(SAP_IMPORT_FOLDER_SETTING, carpeta)
            AuditLog.log("sap_import_folder_set", username=current_user.username,
                         details=f"Carpeta de importacion SAP: {carpeta or '(vacia)'}")
            flash("Carpeta de importación guardada." if carpeta else "Carpeta de importación borrada.", "success")
            return redirect(url_for("licenses.importar"))

        if accion == "importar_carpeta":
            carpeta = AppSetting.get(SAP_IMPORT_FOLDER_SETTING, "")
            scan_resultado = scan_import_folder(carpeta, importers)

            if scan_resultado is None:
                flash("La carpeta configurada no existe o no es accesible desde el servidor.", "error")
            else:
                for item in scan_resultado:
                    if item["ok"]:
                        AuditLog.log("license_import", username=current_user.username,
                                     details=f"{item['tipo']}: {item['count']} filas importadas ({item['filename']}, vía carpeta)")

                ok_count = sum(1 for item 