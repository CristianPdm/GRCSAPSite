"""Calculo del consumo de licencias FUE (Full Use Equivalent) de SAP.

Usa el tipo FUE oficial por usuario (FUE_Users.xlsx, tabla LicenseUser) como
fuente canonica -- es la que SAP factura. El tipo FUE a nivel de rol
(FUE_Rol.xlsx, tabla LicenseRole) queda como referencia/auditoria.

build_fue_comparison() y compute_fue_optimization() cruzan ese FUE oficial
con el FUE derivado de los roles activos (build_user_risk(), del modulo
SOD). Esta es la unica direccion en la que Licencias lee de SOD -- al
reves de la convencion general (SOD lee de Licencias) porque esta
comparativa es, por definicion, propia del modulo de Licencias. El import
se hace de forma local/perezosa dentro de cada funcion para evitar un
ciclo de import a nivel de modulo entre app.sod y app.licenses."""
from datetime import date

from app.licenses.models import LicenseUser
from app.licenses.rules import FUE_LABEL, FUE_ORDER, FUE_WEIGHT, INACTIVITY_THRESHOLD_DAYS


def get_license_summary():
    """Resumen para el tile del dashboard: total de FUEs consumidos,
    desglose por tipo y usuarios con licencia pero sin uso reciente.

    Nombres de campo (`advanced`/`core`/`self_service`/`unassigned`/
    `total_fue`) elegidos para coincidir exactamente con lo que espera
    templates/main/dashboard.html."""
    users = LicenseUser.query.all()

    if not users:
        return {
            "has_data": False,
            "total_users": 0,
            "advanced": 0,
            "core": 0,
            "self_service": 0,
            "unassigned": 0,
            "total_fue": 0,
            "inactive_licensed": 0,
        }

    by_type = {code: 0 for code in FUE_WEIGHT}
    total_fue = 0.0
    today = date.today()
    inactive_licensed = 0

    for user in users:
        code = user.fue_type_code if user.fue_type_code in FUE_WEIGHT else "NONE"
        by_type[code] += 1
        total_fue += FUE_WEIGHT[code]

        if code != "NONE" and user.last_access:
            if (today - user.last_access).days > INACTIVITY_THRESHOLD_DAYS:
                inactive_licensed += 1

    retu