/**
 * Picker de TCodes con busqueda/autocompletado + chips.
 * Replica tcPickerLoadData/tcPickerSearch/tcPickerKey de
 * SAP_SOD_Analyzer_v640.html, adaptado a la lista de TCodes que expone
 * el backend (GET /sod/reglas/tcodes.json) en lugar de leerla de SQLite
 * en el navegador.
 *
 * Marcado esperado (ver templates/sod/rule_form.html):
 *
 *   <div data-tc-picker data-tc-source="{{ url }}" data-tc-initial="ME21N,ME22N">
 *     <div data-tc-tags></div>
 *     <div>
 *       <input data-tc-search>
 *       <div data-tc-drop></div>
 *     </div>
 *     <input type="hidden" name="tcodes1" data-tc-hidden>
 *   </div>
 */
(function () {
  "use strict";

  var cache = {};

  function fetchTcodes(url, callback) {
    if (!url) {
      callback([]);
      return;
    }
    if (cache[url]) {
      callback(cache[url]);
      return;
    }
    fetch(url, { headers: { "X-Requested-With": "XMLHttpRequest" } })
      .then(function (response) {
        return response.ok ? response.json() : [];
      })
      .then(function (data) {
        cache[url] = Array.isArray(data) ? data : [];
        callback(cache[url]);
      })
      .catch(function () {
        callback([]);
      });
  }

  function initPicker(root) {
    var source = root.getAttribute("data-tc-source") || "";
    var initial = (root.getAttribute("data-tc-initial") || "")
      .split(",")
      .map(function (s) { return s.trim().toUpperCase(); })
      .filter(Boolean);

    var tagsEl = root.querySelector("[data-tc-tags]");
    var searchEl = root.querySelector("[data-tc-search]");
    var dropEl = root.querySelector("[data-tc-drop]");
    var hiddenEl = root.querySelector("[data-tc-hidden]");

    var selected = [];
    var allTcodes = [];
    var activeIdx = -1;

    function syncHidden() {
      if (hiddenEl) hiddenEl.value = selected.join(",");
    }

    function hideDrop() {
      dropEl.classList.add("isHidden");
      dropEl.innerHTML = "";
      activeIdx = -1;
    }

    function addTag(raw) {
      var tc = (raw || "").trim().toUpperCase();
      if (!tc || selected.indexOf(tc) !== -1) return;
      selected.push(tc);

      var tag = document.createElement("span");
      tag.className = "tcPicker__tag";
      tag.setAttribute("data-tc", tc);
      tag.appendChild(document.createTextNode(tc));

      var removeBtn = document.createElement("button");
      removeBtn.type = "button";
      removeBtn.className = "tcPicker__tagRemove";
      removeBtn.setAttribute("aria-label", "Quitar " + tc);
      removeBtn.textContent = "×";
      removeBtn.addEventListener("click", function () { removeTag(tc); });
      tag.appendChild(removeBtn);

      tagsEl.appendChild(tag);
      searchEl.value = "";
      hideDrop();
      syncHidden();
    }

    function removeTag(tc) {
      selected = selected.filter(function (x) { return x !== tc; });
      var el = tagsEl.querySelector('[data-tc="' + tc + '"]');
      if (el) el.remove();
      syncHidden();
    }

    function renderDrop(matches, query) {
      activeIdx = -1;

      if (!matches.length && !query) {
        dropEl.innerHTML = '<div class="tcPicker__dropEmpty">' +
          (allTcodes.length
            ? "Todos los TCodes ya estan seleccionados"
            : "Escribi el TCode y presiona Enter para agregarlo") +
          "</div>";
        dropEl.classList.remove("isHidden");
        return;
      }

      var html = matches
        .map(function (tc, i) {
          return '<div class="tcPicker__dropItem" data-idx="' + i + '" data-tc="' + tc + '">' + tc + "</div>";
        })
        .join("");

      if (query && allTcodes.indexOf(query) === -1 && selected.indexOf(query) === -1) {
        html += '<div class="tcPicker__dropItem tcPicker__dropItem--custom" data-tc="' + query + '">' +
          '+ Agregar "' + query + '" manualmente</div>';
      }

      dropEl.innerHTML = html || '<div class="tcPicker__dropEmpty">Sin resultados</div>';
      dropEl.classList.remove("isHidden");
    }

    function search() {
      var q = (searchEl.value || "").trim().toUpperCase();
      var available = allTcodes.filter(function (t) { return selected.indexOf(t) === -1; });
      var matches;

      if (!q) {
        matches = available.slice(0, 60);
      } else {
        var starts = available.filter(function (t) { return t.indexOf(q) === 0; });
        var contains = available.filter(function (t) { return t.indexOf(q) !== 0 && t.indexOf(q) !== -1; });
        matches = starts.concat(contains).slice(0, 80);
      }

      renderDrop(matches, q);
    }

    dropEl.addEventListener("mousedown", function (event) {
      var item = event.target.closest("[data-tc]");
      if (!item) return;
      event.preventDefault();
      addTag(item.getAttribute("data-tc"));
    });

    dropEl.addEventListener("mouseover", function (event) {
      var item = event.target.closest("[data-idx]");
      if (!item) return;
      activeIdx = parseInt(item.getAttribute("data-idx"), 10);
      dropEl.querySelectorAll("[data-idx]").forEach(function (el, i) {
        el.classList.toggle("tcPicker__dropItem--active", i === activeIdx);
      });
    });

    searchEl.addEventListener("input", search);
    searchEl.addEventListener("focus", search);
    searchEl.addEventListener("blur", function () {
      setTimeout(hideDrop, 180);
    });

    searchEl.addEventListener("keydown", function (event) {
      var items = Array.prototype.slice.call(dropEl.querySelectorAll("[data-idx]"));

      if (event.key === "ArrowDown") {
        event.preventDefault();
        activeIdx = Math.min(activeIdx + 1, items.length - 1);
        items.forEach(function (el, i) { el.classList.toggle("tcPicker__dropItem--active", i === activeIdx); });
        if (items[activeIdx]) items[activeIdx].scrollIntoView({ block: "nearest" });
      } else if (event.key === "ArrowUp") {
        event.preventDefault();
        activeIdx = Math.max(activeIdx - 1, 0);
        items.forEach(function (el, i) { el.classList.toggle("tcPicker__dropItem--active", i === activeIdx); });
        if (items[activeIdx]) items[activeIdx].scrollIntoView({ block: "nearest" });
      } else if (event.key === "Enter" || event.key === ",") {
        event.preventDefault();
        if (activeIdx >= 0 && items[activeIdx]) {
          addTag(items[activeIdx].getAttribute("data-tc"));
        } else if (searchEl.value.trim()) {
          addTag(searchEl.value);
        }
      } else if (event.key === "Backspace" && !searchEl.value && selected.length) {
        removeTag(selected[selected.length - 1]);
      } else if (event.key === "Escape") {
        hideDrop();
      }
    });

    initial.forEach(function (tc) { addTag(tc); });

    fetchTcodes(source, function (list) {
      allTcodes = list;
      searchEl.placeholder = list.length
        ? "Buscar entre " + list.length + " TCodes..."
        : "Escribi el TCode manualmente...";
    });
  }

  document.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll("[data-tc-picker]").forEach(initPicker);
  });
})();
